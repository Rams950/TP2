import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import Link from "./Link";
import Resposta from "./Resposta";
import ShowErro from "./ShowErro";

function App() {
  const [resultado, setResultado] = useState("");
  const [erro, setErro] = useState("");

  return (
    <>
      <div className="flex justify-between">
        <div className="text-3xl">TP2</div>
        <div className="flex gap-10 text-sm  text-white">
          {" "}
          <button className="py-0 px-2  bg-black rounded-3xl">Sign Up</button>
          <button className="py-0 px-2 rounded-3xl bg-orange-400">Login</button>
        </div>
      </div>

      <div className="mt-24">
        <h1 className="text-6xl font-bold">
          Faça Resumo de Artigos com{" "}
          <span className="text-orange-400">API de OpenAI</span>
        </h1>
        <p className="mt-6 px-16 text-gray-500 font-bold">
          Esta é um ferramenta para trabalhar com artigos e que pode ser usado
          para transformar artigos longos num resumo claro e conciso
        </p>
      </div>
      <div className="mt-14 mb-14 px-24">
        <Link
          resultado={resultado}
          setResultado={setResultado}
          erro={erro}
          setErro={setErro}
        />

        {resultado && <Resposta resultado={resultado} />}
        {erro && <ShowErro erro={erro} />}
      </div>
    </>
  );
}

export default App;
