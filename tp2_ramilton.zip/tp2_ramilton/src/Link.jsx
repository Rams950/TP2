import { useState, useEffect } from "react";

const Link = ({ resultado, setResultado, erro, setErro, ...props }) => {
  const [historico, setHistorico] = useState([]);
  const [link, setLink] = useState("");

  //obter historicos dos links
  useEffect(() => {
    const hist = JSON.parse(localStorage.getItem("historico_links"));
    if (hist) setHistorico(hist);
  }, []);

  //atualizar dados do historico
  useEffect(() => {
    if (historico.length > 0) {
      localStorage.setItem("historico_links", JSON.stringify(historico));
    }
  }, [historico]);

  const fetchApi = async () => {
    const url = `https://article-extractor-and-summarizer.p.rapidapi.com/summarize?url=${encodeURIComponent(
      link
    )}&lang=pt&engine=2`;

    const options = {
      method: "GET",
      headers: {
        "x-rapidapi-key": "1778d1663emsh527d5c5a7319f59p1bc088jsne4e4969fb042",
        "x-rapidapi-host": "article-extractor-and-summarizer.p.rapidapi.com",
      },
    };
    console.log("enviando a requisicao");

    try {
      const response = await fetch(url, options);
      const result = await response.json();
      if (response.ok) {
        console.log("resultado recebido");
        setResultado(result.summary);
        setHistorico([{ link, resultado: result.summary }, ...historico]);
      } else {
        setErro("Unprocessable Content");
      }
    } catch (error) {
      console.error(error);
      setErro(error.toString());
    }
  };

  return (
    <div>
      <div className="w-full flex  py-3 bg-white rounded-lg items-center">
        <button className="bg-white pl-3 flex items-center">
          <span class="material-icons">link</span>
        </button>
        <input
          className="w-full pl-2 flex items-center pr-3"
          type="text"
          value={link}
          onChange={(e) => setLink(e.target.value)}
          placeholder="Colar o link do artigo"
        />
        <button
          className="bg-white pr-3 flex items-center"
          onClick={() => {
            fetchApi();
          }}
        >
          <span class="material-icons">send</span>
        </button>
      </div>
      <div className="mt-5 flex flex-col gap-3 cursor-pointer">
        {historico.map((hist, index) => (
          <div
            className="w-full bg-white flex rounded-lg py-2 pr-3 "
            onClick={() => {
              setLink(hist.link);
              setResultado(hist.resultado);
            }}
          >
            <button className="pl-3 flex items-center">
              <span class="material-icons">content_copy</span>
            </button>
            <p className="text-blue-400 truncate px-5">{hist.link}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Link;
