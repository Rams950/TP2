const ShowErro = () => {
  return (
    <div className="mt-10">
      <p className="font-bold">Ocorreu um erro ...</p>
      <p className="text-sm text-gray-500">An error occured</p>
    </div>
  );
};

export default ShowErro;
