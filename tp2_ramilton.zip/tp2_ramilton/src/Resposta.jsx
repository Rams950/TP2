const Resposta = ({ resultado, ...props }) => {
  return (
    <div className="mt-10">
      <h3 className="text-2xl text-gray-500 font-bold text-left">
        Este é Resultado do <span className="text-blue-500">Resumo</span>{" "}
      </h3>
      <div className="mt-3 bg-gray-300 p-5 rounded-lg text-justify">
        {resultado}
      </div>
    </div>
  );
};

export default Resposta;
